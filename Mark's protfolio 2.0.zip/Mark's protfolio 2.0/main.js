/* --- JS (main.js) - Final Complete Version --- */

document.addEventListener("DOMContentLoaded", () => {
  /* * ===================================
   * * 1. Element Selection
   * * ===================================
   * */

  const body = document.body;
  const themeSwitcherDot = document.getElementById("theme-switcher");
  const themes = ["light", "dark", "grey"]; // Updated theme array
  const topTextSpans = document.querySelectorAll(".page-top-text span");
  const bottomTextSpans = document.querySelectorAll(
    ".logo-bottom .logo-fullwidth-inner span"
  );
  const globalPreviewContainer = document.getElementById(
    "global-preview-container"
  );
  const worksListContainer = document.getElementById("works-list-container");
  const workItems = document.querySelectorAll(".work-item");
  const taipeiTimeElement = document.getElementById("taipei-time");

  let activeItem = null; // Track the currently active work item
  let currentThemeIndex = 0;
  let lastHoverPositions = []; // Stores { top, left, width, height } for anti-collision & click fixing

  /* * ===================================
   * * 2. Page Load Handling
   * * ===================================
   * */

  loadTheme();
  setTimeout(() => {
    body.classList.remove("preload");
  }, 100);
  startTaipeiTime();
  addClickOutsideListener();
  addThemeClickListeners(); // Add listeners to M ILUN H text

  /* * ===================================
   * * 3. Theme Switcher Logic (Light/Dark/Grey)
   * * ===================================
   * */

  function setTheme(theme) {
    body.dataset.theme = theme;
    localStorage.setItem("theme", theme);
    currentThemeIndex = themes.indexOf(theme);
    // Force redraw of cursor for SVG color update in some browsers
    body.style.cursor = "none";
    requestAnimationFrame(() => {
      body.style.cursor = "";
    });
  }

  function loadTheme() {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme && themes.includes(savedTheme)) {
      setTheme(savedTheme);
    } else {
      const prefersDark =
        window.matchMedia &&
        window.matchMedia("(prefers-color-scheme: dark)").matches;
      setTheme(prefersDark ? "dark" : "light"); // Default to light if no preference
    }
  }

  // Core function to switch to the next theme in the cycle
  function switchToNextTheme() {
    const nextThemeIndex = (currentThemeIndex + 1) % themes.length;
    const nextTheme = themes[nextThemeIndex];
    setTheme(nextTheme);
  }

  // Add click listener to the dot button
  if (themeSwitcherDot) {
    themeSwitcherDot.addEventListener("click", switchToNextTheme);
  }

  // Add click listeners to top and bottom M ILUN H text spans
  function addThemeClickListeners() {
    topTextSpans.forEach((span) => {
      span.addEventListener("click", switchToNextTheme);
    });
    bottomTextSpans.forEach((span) => {
      span.addEventListener("click", switchToNextTheme);
    });
  }

  /* * ===================================
   * * 4. Taipei Real-time Clock
   * * ===================================
   * */

  function updateTaipeiTime() {
    if (!taipeiTimeElement) return;
    const options = {
      timeZone: "Asia/Taipei",
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    };
    // Use 'en-GB' for HH:MM:SS format
    const timeString = new Date().toLocaleTimeString("en-GB", options);
    taipeiTimeElement.textContent = timeString;
  }

  function startTaipeiTime() {
    if (!taipeiTimeElement) return; // Don't start if element doesn't exist
    updateTaipeiTime(); // Run once immediately
    setInterval(updateTaipeiTime, 1000); // Update every second
  }

  /* * ===================================
   * * 5. Works Portfolio Interaction (Bug Fixes Applied)
   * * ===================================
   * */

  workItems.forEach((item) => {
    item.addEventListener("mouseenter", () => {
      // Only show preview on hover if no item is currently active (clicked)
      if (!activeItem) {
        showGlobalPreview(item);
      }
    });

    item.addEventListener("mouseleave", () => {
      // Only clear preview on leave if no item is currently active (clicked)
      if (!activeItem) {
        clearGlobalPreview();
      }
    });

    item.addEventListener("click", () => {
      const isAlreadyActive = item === activeItem;

      // If clicking a *different* item while one is already active...
      if (activeItem && !isAlreadyActive) {
        // Close the previous one first
        activeItem.classList.remove("is-active");
        closeConcept(activeItem);
        clearGlobalPreview(); // Clear images associated with the old item
      }

      // Handle the currently clicked item
      if (isAlreadyActive) {
        // Clicking the active item again: Close it
        activeItem = null; // Unset active item
        item.classList.remove("is-active");
        closeConcept(item);
        clearGlobalPreview(); // Clear the locked preview images
      } else {
        // Clicking a new item (or the first): Open it
        activeItem = item; // Set as active item
        item.classList.add("is-active");
        openConcept(item);

        // Ensure preview images are shown, using hover positions if available
        // If hover didn't fire (e.g., clicked too fast), this will draw them
        // If hover did fire, this won't redraw due to the check inside showGlobalPreview
        showGlobalPreview(item);
        // Images will now remain because activeItem is set, blocking mouseleave clear
      }
    });
  });

  /* * ===================================
   * * 6. Click Outside Logic (Close Active Work Item)
   * * ===================================
   * */

  function addClickOutsideListener() {
    document.addEventListener("click", (event) => {
      // Check: Is an item active? Was the click outside the list container?
      if (
        activeItem &&
        worksListContainer &&
        !worksListContainer.contains(event.target)
      ) {
        // Additional checks: Was the click NOT on the preview images or the theme switcher/text?
        let clickedOnPreview = globalPreviewContainer
          ? globalPreviewContainer.contains(event.target)
          : false;
        let clickedOnSwitcher = themeSwitcherDot
          ? themeSwitcherDot.contains(event.target)
          : false;
        let clickedOnTopText = Array.from(topTextSpans).some((span) =>
          span.contains(event.target)
        );
        let clickedOnBottomText = Array.from(bottomTextSpans).some((span) =>
          span.contains(event.target)
        );

        if (
          !clickedOnPreview &&
          !clickedOnSwitcher &&
          !clickedOnTopText &&
          !clickedOnBottomText
        ) {
          // Close the active item
          activeItem.classList.remove("is-active");
          closeConcept(activeItem);
          clearGlobalPreview();
          activeItem = null;
        }
      }
    });
  }

  /* * ===================================
   * * 7. Helper Functions - Strengthened Anti-Collision
   * * ===================================
   * */

  /**
   * Checks if two rectangles overlap with a buffer.
   * @param {object} rect1 - { top, left, width, height }
   * @param {object} rect2 - { top, left, width, height }
   * @returns {boolean}
   */
  function checkCollision(rect1, rect2) {
    const buffer = 30; // Increased buffer for more space
    return (
      rect1.left < rect2.left + rect2.width + buffer &&
      rect1.left + rect1.width + buffer > rect2.left &&
      rect1.top < rect2.top + rect2.height + buffer &&
      rect1.top + rect1.height + buffer > rect2.top
    );
  }

  /**
   * Displays preview images fullscreen, attempting to avoid overlap.
   * Uses lastHoverPositions if available and item is active, otherwise calculates new positions.
   * @param {HTMLElement} item - The work item being hovered or clicked.
   */
  function showGlobalPreview(item) {
    // If the item is already active and images are present, don't redraw
    if (
      item === activeItem &&
      globalPreviewContainer &&
      globalPreviewContainer.children.length > 0
    ) {
      return;
    }

    clearGlobalPreview(); // Always clear previous images first
    if (!globalPreviewContainer) return;

    const images = item.dataset.images
      .split(",")
      .filter((src) => src.trim() !== "");
    if (images.length === 0) return; // Exit if no images

    const viewHeight = window.innerHeight;
    const viewWidth = window.innerWidth;
    const imgMaxWidth = 400;
    const imgMaxHeight = 600; // Estimate height for collision checking

    images.forEach((imgSrc) => {
      let attempts = 0;
      let isSafe = false;
      let position = {}; // { top, left, width, height }

      // Try to find a non-overlapping position
      while (!isSafe && attempts < 100) {
        // Increased attempts
        attempts++;
        let randTop = Math.random() * (viewHeight - imgMaxHeight);
        let randLeft = Math.random() * (viewWidth - imgMaxWidth);

        position = {
          top: Math.max(20, Math.min(randTop, viewHeight - imgMaxHeight - 20)), // Add edge buffer
          left: Math.max(20, Math.min(randLeft, viewWidth - imgMaxWidth - 20)), // Add edge buffer
          width: imgMaxWidth,
          height: imgMaxHeight, // Use estimate for collision check
        };

        // Check collision against images already placed *in this hover event*
        const isOverlapping = lastHoverPositions.some((placedPos) =>
          checkCollision(placedPos, position)
        );

        if (!isOverlapping) {
          isSafe = true; // Found a safe spot
        }
        // If max attempts reached, accept the last position
        if (attempts === 100) {
          console.warn(
            "Could not find a guaranteed non-overlapping position after 100 attempts for",
            imgSrc,
            ". Placing anyway."
          );
          isSafe = true; // Force exit loop
        }
      }

      // Store the calculated position (for the current hover/active state)
      lastHoverPositions.push({ ...position }); // Store a copy with estimated H

      // Create and display the image
      const img = document.createElement("img");
      img.src = imgSrc;
      img.className = "preview-image";
      img.style.top = `${position.top}px`;
      img.style.left = `${position.left}px`;
      globalPreviewContainer.appendChild(img);
      // Trigger fade-in animation
      setTimeout(() => {
        img.classList.add("is-visible");
      }, 10);
    });
  }

  /**
   * Clears all preview images from the global container.
   */
  function clearGlobalPreview() {
    if (globalPreviewContainer) {
      globalPreviewContainer.innerHTML = "";
    }
    lastHoverPositions = []; // Reset position cache
  }

  /**
   * Opens the concept details for a work item.
   * @param {HTMLElement} item - The work item element.
   */
  function openConcept(item) {
    const conceptWrapper = item.querySelector(".concept-wrapper");
    if (!conceptWrapper) return;
    const conceptText = item.dataset.concept;
    // Set content only if empty
    if (conceptWrapper.innerHTML.trim() === "") {
      conceptWrapper.innerHTML = `<p>${conceptText || ""}</p>`;
    }
    // Use rAF to ensure layout calculation before setting maxHeight
    requestAnimationFrame(() => {
      if (conceptWrapper && conceptWrapper.firstChild) {
        // Check if still exists
        conceptWrapper.style.maxHeight = conceptWrapper.scrollHeight + "px";
      }
    });
  }

  /**
   * Closes the concept details for a work item.
   * @param {HTMLElement} item - The work item element.
   */
  function closeConcept(item) {
    const conceptWrapper = item.querySelector(".concept-wrapper");
    if (conceptWrapper) {
      conceptWrapper.style.maxHeight = "0";
      // Optional: Remove content after transition for potential performance gain
      // conceptWrapper.addEventListener('transitionend', () => {
      //     if (conceptWrapper && parseFloat(conceptWrapper.style.maxHeight) === 0) {
      //         // Check if it's still closed and not the active item before removing
      //         if (item !== activeItem) {
      //              conceptWrapper.innerHTML = '';
      //         }
      //     }
      // }, { once: true });
    }
  }
}); // DOMContentLoaded End
